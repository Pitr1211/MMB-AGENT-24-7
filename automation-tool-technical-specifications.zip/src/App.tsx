import { useEffect } from 'react';
import Sidebar from './components/Sidebar';
import TopBar from './components/TopBar';
import Dashboard from './components/Dashboard';
import ProfilesPage from './components/ProfilesPage';
import JobQueuePage from './components/JobQueuePage';
import ProxyManagerPage from './components/ProxyManagerPage';
import LogsPage from './components/LogsPage';
import SettingsPage from './components/SettingsPage';
import { useStore } from './store/useStore';
import type { OS, TaskType } from './types';

export default function App() {
  const {
    profiles, jobs, logs, activeTab, setActiveTab,
    createProfile, startProfile, stopProfile, deleteProfile, recreateProfile,
    toggleSelect, selectAll, deselectAll, startSelected, stopSelected,
    addJob, retryJob, clearLogs, renewProxy,
  } = useStore();

  const runningCount = profiles.filter(p => p.status === 'running').length;
  const pendingJobs = jobs.filter(j => j.status === 'pending').length;

  // Check proxy expiry every 10 minutes (simulated)
  useEffect(() => {
    const interval = setInterval(() => {
      // In a real app this would trigger proxy renewal checks
    }, 600000);
    return () => clearInterval(interval);
  }, []);

  const renderPage = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard profiles={profiles} jobs={jobs} setActiveTab={setActiveTab} />;
      case 'profiles':
        return (
          <ProfilesPage
            profiles={profiles}
            onCreateProfile={(os: OS) => createProfile(os)}
            onStartProfile={startProfile}
            onStopProfile={stopProfile}
            onDeleteProfile={deleteProfile}
            onRecreateProfile={recreateProfile}
            onToggleSelect={toggleSelect}
            onSelectAll={selectAll}
            onDeselectAll={deselectAll}
            onStartSelected={startSelected}
            onStopSelected={stopSelected}
            onRenewProxy={renewProxy}
            onAddJob={(profileId: string, taskType: TaskType, details?: string) => addJob(profileId, taskType, details)}
          />
        );
      case 'jobs':
        return <JobQueuePage jobs={jobs} onRetry={retryJob} />;
      case 'proxy':
        return <ProxyManagerPage profiles={profiles} onRenewProxy={renewProxy} />;
      case 'logs':
        return <LogsPage logs={logs} onClear={clearLogs} />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <Dashboard profiles={profiles} jobs={jobs} setActiveTab={setActiveTab} />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-950 text-white overflow-hidden">
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        runningCount={runningCount}
        pendingJobs={pendingJobs}
      />
      <main className="flex-1 overflow-hidden flex flex-col">
        <TopBar profiles={profiles} logs={logs} activeTab={activeTab} />
        <div className="flex-1 overflow-hidden flex flex-col">
          {renderPage()}
        </div>
      </main>
    </div>
  );
}
